# Electron Mongodb CRUD
![](./screenshot.png)